<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        #success-message {
            background-color: greenyellow;
            color: green;
            margin: 10px;
            padding: 10px;
            position: absolute;
            right: 15px;
            top: 15px;
            display: none;
        }

        #error-message {
            background: #EFDCDD;
            color: red;
            padding: 10px;
            margin: 10px;
            position: absolute;
            display: none;
            right: 15px;
            top: 15px;
        }

        .delete-btn {
            background-color: red;
            color: white;
            border: 0;
            padding: 4px 10px;
            border-radius: 3px;
            cursor: pointer;

        }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">

    <link href='bootstrap/css/bootstrap.min.css' rel='stylesheet' type='text/css'>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src='bootstrap/js/bootstrap.min.js'></script>
    <script src='bootbox.min.js'></script>
</head>

<body>
    <table id="main" border="0" cellspacing="0">
        <tr>
            <td id="header">
                <h1>PHP with Ajax</h1>
            </td>
        </tr>
        <tr>
            <td id="table-form">
                <form id="addForm">
                    First Name : <input type="text" id="fname">&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;
                    Last Name : <input type="text" id="lname">
                    <input type="button" id="save-button" value="save">
                </form>
            </td>
        </tr>
        <tr>
            <td id="table-data">
                <!-- <table border="1px" width="100%" cellspacing="0" cellpadding="10px">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                    </tr>
                    <tr>
                        <td align="center">1</td>
                        <td>yahoo baba</td>
                    </tr>
                </table> -->
            </td>
        </tr>
    </table>
    <div id="error-message"></div>
    <div id="success-message"></div>
    <script type="text/javascript">
        $(document).ready(function() {
            function loadTable() {
                $.ajax({
                    url: "ajax-load.php",
                    type: "POST",
                    success: function(data) {
                        $("#table-data").html(data);
                    }
                })
            }
            loadTable();



            $("#save-button").on("click", function(e) {
                // console.log(e);
                e.preventDefault();
                var fname = $("#fname").val();
                var lname = $("#lname").val();
                if (fname == "" || lname == "") {
                    $("#error-message").html("All fields are required").slideDown().delay(2000).fadeOut();;
                    $("#success-message").slideup();
                } else {
                    $.ajax({
                        url: "ajax-insert.php",
                        type: "POST",
                        // dataType: "json",
                        data: {
                            "first_name": fname,
                            "last_name": lname
                        },
                        success: function(response) {
                            if (response == 1) {
                                loadTable();
                                $("#addForm").trigger("reset");
                                $("#success-message").html("data inserted successfully").slideDown().delay(2000).fadeOut();

                                // $("#success-message").html("data inserted successfully").slideToggle(2000);

                                $("#error-message").slideup();
                            } else {
                                // alert("can't save records");
                                $("#success-message").slideup();
                                $("#error-message").html("can't save records").slideDown();
                            }

                        }

                    });
                }
                // alert(fname);
                // alert(lname);

            })

            $(document).on("click", ".delete-btn", function() {
                var studentID = $(this).data("id");
                var element = this;
                alert(studentID);


                if (confirm("do you want to delete it ?")) {
                    $.ajax({
                        url: "ajax-delete.php",
                        type: "POST",
                        data: {
                            "id": studentID
                        },
                        success: function(data) {
                            if (data == 1) {
                                $(element).closest("tr").fadeOut();
                            } else {
                                $("#success-message").slideup();
                                $("#error-message").html("can't delete records").slideDown().delay(2000).fadeOut();
                            }
                        }
                    })
                }
                // $.ajax({
                //     url: "ajax-delete.php",
                //     type: "POST",
                //     data: {
                //         "id": studentID
                //     },
                //     success: function(data) {
                //         if (data == 1) {
                //             $(element).closest("tr").fadeOut();
                //         } else {
                //             $("#success-message").slideup();
                //             $("#error-message").html("can't delete records").slideDown().delay(2000).fadeOut();
                //         }
                //     }
                // })

            })
        })
    </script>

</body>

</html>