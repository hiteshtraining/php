<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        #success-message {
            background-color: greenyellow;
            color: green;
            margin: 10px;
            padding: 10px;
            position: absolute;
            right: 15px;
            top: 15px;
            display: none;
        }

        #error-message {
            background: #EFDCDD;
            color: red;
            padding: 10px;
            margin: 10px;
            position: absolute;
            display: none;
            right: 15px;
            top: 15px;
        }

        .delete-btn {
            background-color: red;
            color: white;
            border: 0;
            padding: 4px 10px;
            border-radius: 3px;
            cursor: pointer;
        }

        .edit-btn {
            background-color: grey;
            color: white;
            border: 0;
            padding: 4px 10px;
            border-radius: 3px;
            cursor: pointer;
        }

        #modal {
            background: rgba(0, 0, 0, .7);
            position: fixed;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            z-index: 100;
            display: none;
        }

        #modal-form {
            background: #fff;
            width: 30%;
            position: relative;
            top: 20%;
            left: calc(20%);
            padding: 15px;
            border-radius: 4px;
        }
        #close-btn{
            background: red;
            color: white;
            width: 30px;
            height: 30px;
            line-height: 30px;
            position: absolute;
            top: -15px;
            right: -15px;
            cursor: pointer;
        }
        #pagination a{
            padding: 20px;
            margin-top: 20px;
        }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous"> -->

</head>

<body>
    <table id="main" border="0" cellspacing="0">
        <tr>
            <td id="header">
                <h1>PHP with Ajax</h1>
                <div id="search-bar">
                    <label for="">Search : </label>
                    <input type="text" id="search" autocomplete="off">
                </div>
            </td>
        </tr>
        <tr>
            <td id="table-form">
                <form id="addForm">
                    First Name : <input type="text" id="fname">&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;
                    Last Name : <input type="text" id="lname">
                    <input type="button" id="save-button" value="save">
                </form>
            </td>
        </tr>
        <tr>
            <td id="table-data">
                <!-- <table border="1px" width="100%" cellspacing="0" cellpadding="10px">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                    </tr>

                        <tr><td align="center">1</td><td>Stu name 1</td></tr>
                        <tr><td align="center">1</td><td>Stu name 1</td></tr>
                        <tr><td align="center">1</td><td>Stu name 1</td></tr>
                        <tr><td align="center">1</td><td>Stu name 1</td></tr>


                </table> -->
            </td>
        </tr>
    </table>
    <!-- // pagination -->
    <!-- <div id="pagination">
        <a href="" id="1" class="active">1</a>
        <a href="" id="2" class="">1</a>
        <a href="" id="3" class="">1</a>
    </div> -->
    <div id="error-message"></div>
    <div id="success-message"></div>
    <div id="modal">
        <div id="modal-form">
            <h2>Edit form</h2>
            <table cellpadding="0" width="100%">
                <!-- <tr>
                    <td>First Name</td>
                    <td><input type="text" id="edit-fname"></td>
                </tr>
                <tr>
                    <td>Last Name</td>
                    <td><input type="text" id="edit-lname"></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" id="edit-submit" value="save"></td>
                </tr> -->
            </table>
            <div id="close-btn">X</div>
        </div>
    </div>
    <script type="text/javascript">
        $(document).ready(function() {
            function loadTable() {
                $.ajax({
                    url: "ajax-load.php",
                    type: "POST",
                    success: function(data) {
                        $("#table-data").html(data);
                    }
                })
            }
            loadTable();



            $("#save-button").on("click", function(e) {
                // console.log(e);
                e.preventDefault();
                var fname = $("#fname").val();
                var lname = $("#lname").val();
                if (fname == "" || lname == "") {
                    $("#error-message").html("All fields are required").slideDown().delay(2000).fadeOut();;
                    $("#success-message").slideup();
                } else {
                    $.ajax({
                        url: "ajax-insert.php",
                        type: "POST",
                        // dataType: "json",
                        data: {
                            "first_name": fname,
                            "last_name": lname
                        },
                        success: function(response) {
                            if (response == 1) {
                                loadTable();
                                $("#addForm").trigger("reset");
                                $("#success-message").html("data inserted successfully").slideDown().delay(2000).fadeOut();

                                // $("#success-message").html("data inserted successfully").slideToggle(2000);

                                $("#error-message").slideup();
                            } else {
                                // alert("can't save records");
                                $("#success-message").slideup();
                                $("#error-message").html("can't save records").slideDown();
                            }

                        }

                    });
                }
                // alert(fname);
                // alert(lname);

            })

            $(document).on("click", ".delete-btn", function() {
                var studentID = $(this).data("id");
                var element = this;
                alert(studentID);


                if (confirm("do you want to delete it ?")) {
                    $.ajax({
                        url: "ajax-delete.php",
                        type: "POST",
                        data: {
                            "id": studentID
                        },
                        success: function(data) {
                            if (data == 1) {
                                $(element).closest("tr").fadeOut();
                            } else {
                                $("#success-message").slideup();
                                $("#error-message").html("can't delete records").slideDown().delay(2000).fadeOut();
                            }
                        }
                    })
                }
                // $.ajax({
                //     url: "ajax-delete.php",
                //     type: "POST",
                //     data: {
                //         "id": studentID
                //     },
                //     success: function(data) {
                //         if (data == 1) {
                //             $(element).closest("tr").fadeOut();
                //         } else {
                //             $("#success-message").slideup();
                //             $("#error-message").html("can't delete records").slideDown().delay(2000).fadeOut();
                //         }
                //     }
                // })

            })

            // show modal box

            $(document).on("click", ".edit-btn", function() {
                $("#modal").show();
                var studentID = $(this).data("eid");
                // var element = this;
                alert(studentID);

                $.ajax({
                    url : "ajax-load-edit.php",
                    type : "POST",
                    data : {"id": studentID},
                    success : function(data){
                        $("#modal-form table").html(data);
                    }
                })
            })

            // hide modal box
            $("#close-btn").on("click",function(){
                $("#modal").hide();
            })

            // save edit form
            $(document).on("click","#edit-submit",function(){
                var stuID = $("#edit-id").val();
                var fname = $("#edit-fname").val();
                var lname = $("#edit-lname").val();

                $.ajax({
                    url : "ajax-update-form.php",
                    type : "POST",
                    data : { id : stuID,
                        first_name : fname,
                        last_name: lname},
                    success : function(data){
                        if(data ==1){
                            $("#modal").hide();
                            loadTable();
                        }
                    }
                })
            })

            // live search
            $("#search").on("keyup",function(){
                var search_term = $(this).val();

                $.ajax({
                    url : "ajax-search.php",
                    type : "POST",
                    data : {
                        search: search_term
                    },
                    success : function(data){
                        $("#table-data").html(data);
                    }

                })
            })

        })
    </script>
    <script type="text/javascript">
        $(document).ready(function(){
            function loadTablePage(page){
                $.ajax({
                    url : "ajax-pagination.php",
                    type : "POST",
                    data : {page_no: page},
                    success : function(data){
                        $("#table-data").html(data);
                    }
                })
            }
            loadTablePage();
//




        // pagination call
        $(document).on("click","#pagination a", function(e){
            e.preventDefault();
            var page_id = $(this).attr("id");

            loadTablePage(page_id);

        })
        })
    </script>

</body>

</html>