<?php

$serach_value = $_POST['search'];

$conn = mysqli_connect("localhost","root","","test") or die("connection failed");

$sql = "SELECT * FROM students WHERE first_name LIKE '%{$serach_value}%' OR last_name LIKE'%{$serach_value}%' ";

$result = mysqli_query($conn, $sql) or die("sql query failed.");
// echo "test2";
$output = "";
// echo"<pre>";
// print_r(mysqli_fetch_assoc($result));
// echo"</pre>";
// exit;
if(mysqli_num_rows($result)> 0){
    $output = '<table border="1px" width="100%" cellspacing="0" cellpadding="10px">
    <tr>
        <th widht="100px">Id</th>
        <th widht="200px"> Name</th>
        <th widht="100px"> operation edit </th>
        <th widht="100px"> operation Delete </th>


    </tr>';
     // <th>Last Name </th>


// $result1 = mysqli_fetch_all($result);
// echo"<pre>";
// print_r($result1);
// echo"</pre>";
// exit;
    // foreach($result1 as $row){
    //     $output .=
    //         "<tr>
    //             <td>{$row[0]}</td>
    //             <td>{$row[1]}</td>
    //             <td>{$row[2]}</td>
    //         </tr>";
    // }

    while($row = mysqli_fetch_assoc($result)){
        $output .=
        "<tr>
            <td>{$row['id']}</td>
            <td>{$row['first_name']} {$row['last_name']}</td>
            <td><button class ='edit-btn' data-eid='{$row['id']}' >Edit </button></td>
            <td><button class ='delete-btn' data-id='{$row['id']}' >DELETE </button></td>

        </tr>";
    }
    // <td>{$row['last_name']}</td>
    $output .="</table>";

    mysqli_close($conn);
    echo $output;
}else{
    echo "record not found";
}

// die();